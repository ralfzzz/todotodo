// $(".nav-bar").click(function(){
//     alert("Body clicked.");
//   });